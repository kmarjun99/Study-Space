# CA Review Notes — StudySpace Canary Pack

This document is a standalone checklist for your tax review. Please mark each
item with your decision and any notes. Supporting artifacts referenced in each
question are in this same folder.

**Pack generated**: 2026-05-28T15:55:47.937193Z
**Reviewer (CA name)**: ______________________________
**Firm**: ______________________________
**Date reviewed**: ______________________________

---

## 1. Booking GST rate

Is `18%` the correct GST rate for reading-room / cabin / seat bookings on StudySpace, or should a different rate apply?

**Engine setting**: `gst.booking.default_rate = 0.18` in `tax_config`.

**Artifacts to review**:
- `bookings.csv` — line `bk-a` (Rs. 2,500.00 = Rs. 2,118.64 taxable + Rs. 381.36 GST)
- `01_owner_tax_invoice_*.pdf` — sample registered-owner booking invoice

**Your answer**:
- [ ] 18% confirmed
- [ ] Different rate: _____ %  (rationale: _________________________________)

**Notes**:

_________________________________________________________________

## 2. SAC code for reading-room / cabin bookings

Is `996311` (Room or unit accommodation services) the correct SAC for our supply, or should it be a coworking / business-support SAC (e.g., 997212, 998313)?

**Engine setting**: `gst.booking.default_sac = '996311'` in `tax_config`.

**Artifacts to review**:
- `01_owner_tax_invoice_*.pdf` — SAC column on line item

**Your answer**:
- [ ] 996311 confirmed
- [ ] Use SAC: _________ for reading-room / cabin
- [ ] Use SAC: _________ for hostel / PG
- [ ] Use SAC: _________ for short-stay / hotel-like

**Notes**:

_________________________________________________________________

## 3. Hostel / PG category treatment

Is a HOSTEL_PG stay (continuous, residential) **exempt**, **taxable at 12%**, or **treatment-dependent** on per-unit-per-day tariff / monthly amount per person?

**Engine setting**: `gst.booking.exempt_threshold_monthly = 20000` in `tax_config` (currently a placeholder; we will replace with whatever you confirm).

**Artifacts to review**:
- `02_non_gst_receipt_*.pdf` — booking `bk-b` (Rs. 1,800.00, unregistered owner, HOSTEL_PG)
- `bookings.csv` — see treatment column for `bk-b`

**Your answer**:
- [ ] HOSTEL_PG is exempt under current GST rules (no threshold)
- [ ] HOSTEL_PG is taxable at _____ % unconditionally
- [ ] HOSTEL_PG is exempt up to Rs. _________ per person per month; above that, taxable at _____ %

**Notes**:

_________________________________________________________________

## 4. Section 9(5) applicability per category

For each StudySpace category, when supplied through StudySpace by an **unregistered owner**, does Section 9(5) of the CGST Act make StudySpace (the e-commerce operator) the deemed supplier?

**Engine setting**: `gst.booking.sec_9_5_eligible_categories = ['HOTEL_LIKE', 'SHORT_STAY']` in `tax_config`.

**Artifacts to review**:
- `03_eco_tax_invoice_sec_9_5_*.pdf` — booking `bk-c` (Rs. 3,000.00, unregistered owner, HOTEL_LIKE)

**Your answer** (mark Yes / No per category):
| Category | Sec 9(5) applies? |
| --- | --- |
| HOTEL_LIKE | [ ] Yes  [ ] No |
| SHORT_STAY | [ ] Yes  [ ] No |
| HOSTEL_PG  | [ ] Yes  [ ] No |
| READING_ROOM | [ ] Yes  [ ] No |
| OTHER      | [ ] Yes  [ ] No |

**Notes**:

_________________________________________________________________

## 5. TCS / TDS — enable now or later?

Should we enable TCS (Sec 52 CGST, 0.5%) and TDS u/s 194-O (0.1%) from day 1 of going live, or after 2–3 months of clean booking data?

**Engine setting**: both `tcs.enabled` and `tds.section_194o_enabled` are OFF in production config. The canary above turned TCS on to demonstrate the math.

**Artifacts to review**:
- `07_settlement_owner_a_*.pdf` — shows TCS Rs. 10.60 deducted from gross
- `settlements.csv` — `tcs` column per run

**Your answer** (pick one for each):
| Deduction | Decision |
| --- | --- |
| TCS Sec 52 CGST | [ ] Enable at go-live  [ ] Enable after _____ months  [ ] Not applicable |
| TDS Sec 194-O   | [ ] Enable at go-live  [ ] Enable after _____ months  [ ] Not applicable |

**Notes**:

_________________________________________________________________

## 6. Owner-issued invoice format (acceptability)

StudySpace generates the tax invoice **on behalf of** GST-registered owners using the owner's GSTIN, with a footer disclosing StudySpace as the facilitator under Sec 2(45) CGST. Is this format acceptable for owner GSTR-1 reporting, and is anything missing for future e-invoicing (IRN/QR) when an owner crosses the AATO threshold?

**Artifacts to review**:
- `01_owner_tax_invoice_*.pdf` — full format and footer
- `06b_maintenance_fee_*.pdf` — StudySpace-as-supplier counter-example (SS/PLF/26-27/000004)

**Your answer**:
- [ ] Format is acceptable as-is
- [ ] Acceptable with these changes: _______________________________________
- [ ] Format is not acceptable; rebuild per: __________________________________

**E-invoicing readiness** (IRN/QR fields present in DB but not rendered):
- [ ] No action needed until owner AATO crosses Rs. 5 cr threshold
- [ ] Action needed now — please specify: ____________________________________

**Notes**:

_________________________________________________________________

## 7. Credit note format (Sec 34 CGST compliance)

Are the credit notes generated by StudySpace compliant with Section 34 of the CGST Act, 2017? Do you require explicit linkage to the original invoice number on the face of the document?

**Artifacts to review**:
- `04_refund_before_settlement_*.pdf` — credit note `SS/CN/26-27/000001` for refund before settlement
- `05_refund_after_settlement_*.pdf` — credit note `SS/CN/26-27/000002` for refund after settlement

**Your answer**:
- [ ] Format compliant with Sec 34 as-is
- [ ] Compliant with these changes: _______________________________________
- [ ] Original-invoice linkage must appear on the face of the credit note
- [ ] Original-invoice linkage in our records is sufficient (not on face)

**Notes**:

_________________________________________________________________

---

## Reviewer sign-off

I have reviewed the canary pack and the above seven items represent my confirmed positions for StudySpace's go-live configuration.

Signature: ______________________________

Date: ______________________________

Membership / ICAI no.: ______________________________

---

## Engineering notes (for follow-up after CA returns this form)

Once the CA returns this form, engineering will:

1. Update `tax_config` keys via super-admin `/super-admin/tax-config` to match the confirmed values (rates, SAC, exempt threshold, Sec 9(5) list).
2. Re-run `python -m scripts.canary_walkthrough` and confirm artifacts reflect the new config.
3. Run `python -m scripts.canary_validate_listing` against one real listing on staging to confirm end-to-end behaviour.
4. Only then enable production flags one at a time, in this order: `accounting.enabled` → `feature.gst_invoices` → `feature.recurring_maintenance` → `feature.credit_notes` → `tcs.enabled` / `tds.section_194o_enabled`.
