# StudySpace canary walkthrough — CA review pack

Generated at: 2026-05-28T15:55:47.935980Z

This package demonstrates StudySpace's GST + settlement engine end-to-end.
All accounting feature flags are ON for the demo; in production they remain OFF
until each one is reviewed and signed off.

## Cast
- **Student**: Ananya R
- **Owner A — GST-registered (Scenario 1)**: Acme Reading Rooms Pvt Ltd (GSTIN `29ACMEZ1234Z1Z5`)
  - Listing: *Acme Hostel — Indiranagar* — category `HOSTEL_PG`, state `KA`
- **Owner B — Unregistered, HOSTEL_PG / non-Sec 9(5) (Scenario 2)**: Bharat Lodge (no GSTIN)
  - Listing: *Bharat Lodge — Jayanagar* — category `HOSTEL_PG`, state `KA`
- **Owner C — Unregistered, HOTEL_LIKE / Sec 9(5) eligible (Scenario 3)**: Comfort Stays (no GSTIN)
  - Listing: *Comfort Stays — Koramangala* — category `HOTEL_LIKE`, state `KA`

## Scenario-by-scenario
1. **GST-registered owner booking** — booking `bk-a`, paid Rs. 2,500.00. Treatment `OWNER_REGISTERED` → base Rs. 2,118.64, GST Rs. 381.36. Document: `OWNER_TAX_INVOICE`. Owner is the supplier of record. Owner GSTIN appears on the invoice. Owner pays output GST in own GSTR-1.

2. **Unregistered owner, non-Sec 9(5)** — booking `bk-b`, paid Rs. 1,800.00. Treatment `NOT_REGISTERED` → base Rs. 1,800.00, GST Rs. 0.00. Document: `NON_GST_RECEIPT`. No GST is collected on this supply. Receipt clearly states the supplier is unregistered and StudySpace is only the facilitator.

3. **Unregistered owner, Sec 9(5) eligible** — booking `bk-c`, paid Rs. 3,000.00. Treatment `SEC_9_5` → base Rs. 2,542.37, GST Rs. 457.63. Document: `ECO_TAX_INVOICE`. StudySpace is the deemed supplier under Sec 9(5). Owner is disclosed as the underlying supplier but not the GST supplier of record.

4. **Refund BEFORE settlement** on Owner A booking — refund Rs. 500. Credit note **SS/CN/26-27/000001** issued; ledger group reverses the original booking proportionally; settlement that follows shows the refund as a deduction.

5. **Refund AFTER settlement** on Owner B booking — refund Rs. 200, raised after Owner B's payout was already marked PAID. Credit note **SS/CN/26-27/000002** issued; in production this would create a `RECOVERY_PENDING` debit against Owner B's next settlement. **CA: please review whether immediate recovery from owner or a netted next-cycle adjustment is preferable.**

6. **Monthly maintenance fee** on Owner A's listing — Rs. 499 + 18% GST. Platform tax invoice **SS/PLF/26-27/000004** issued (StudySpace as supplier, owner as recipient).

7. **Owner settlement statements** — one per owner:
   - Owner A `cd528cc2`: gross Rs. 2,500.00 − refunds Rs. 500.00 − TCS Rs. 10.60 − TDS Rs. 0.00 = **net Rs. 1,989.40** (READY)
   - Owner B `8605456d`: gross Rs. 1,800.00 − refunds Rs. 0.00 − TCS Rs. 0.00 − TDS Rs. 0.00 = **net Rs. 1,800.00** (PAID, UTR HDFC-CANARY-B-001)
   - Owner C `68a08f3e`: gross Rs. 2,542.37 − refunds Rs. 0.00 − TCS Rs. 0.00 − TDS Rs. 0.00 = **net Rs. 2,542.37** (READY)

## Ledger integrity
- Imbalanced txn groups: **0** (expected 0)
- Every row in `ledger.csv` has exactly one of debit/credit non-zero.
- Σdebit equals Σcredit for every `txn_group_id`.

---

## CA review checklist

Please review the artifacts in this folder and confirm:

1. **Booking GST rate** — Is `18%` the correct rate for reading-room / cabin / seat bookings? If different (e.g., 12% for hostel-style accommodation), tell us the exact rate and we will update `gst.booking.default_rate` in `tax_config`.

2. **SAC code** — Is `996311` correct for reading-room / cabin usage? If the supply is closer to coworking / business support, advise the right SAC (e.g., 997212, 998313) and we will set per-listing `gst_sac`.

3. **Hostel / PG category** — Is a HOSTEL_PG stay (continuous, residential) exempt, taxable at 12%, or treatment-dependent on the per-unit-per-day tariff? Please flag the threshold and we will encode it in `tax_config` (`gst.booking.exempt_threshold_monthly`).

4. **Section 9(5) applicability** — Among our categories (HOTEL_LIKE, SHORT_STAY, HOSTEL_PG, READING_ROOM, OTHER) which qualify as 'specified services' u/s 9(5) when supplied through an ECO by an unregistered owner? We currently list `[HOTEL_LIKE, SHORT_STAY]`.

5. **TCS / TDS timing** — Should we enable `tcs.enabled` (0.5% Sec 52 CGST) and `tds.section_194o_enabled` (0.1% Income Tax) from day 1 of going live, or after 2-3 months of clean booking data? Both flags are currently OFF in production config; the canary above turned TCS on to demonstrate the math.

6. **Owner-issued invoice format** — Open `01_owner_tax_invoice_*.pdf`. Is the platform-on-behalf-of-supplier format and disclosure footer acceptable for your registered owners' GSTR-1 reporting? Anything missing for e-invoicing (IRN/QR) when an owner crosses the AATO threshold?

7. **Credit note format** — Open `04_refund_before_settlement_*.pdf` and `05_refund_after_settlement_*.pdf`. Are both compliant with Section 34 of CGST Act, 2017? Do you require explicit linkage to the original invoice number on the face of the document (we have the field, currently omitted because the OWNER_TAX_INVOICE was not yet linked in this synthetic run)?

---

## What is NOT enabled yet (intentional)
- `feature.per_listing_price_mode` — per-listing GST_INCLUDED / GST_EXTRA override. Live booking math stays GST-inclusive globally for now.
- `settlement.offset_maintenance` — auto-deduction of unpaid maintenance fees from owner payouts. Maintenance is still billed separately.
- GSTR-1 / GSTR-8 / 26Q export endpoints. Manual review of the CSVs in this folder is the current path; exports will ship after this CA review.
